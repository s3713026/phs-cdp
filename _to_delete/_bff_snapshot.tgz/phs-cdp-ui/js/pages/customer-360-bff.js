/**
 * PHS CDP — Customer 360 BFF Integration Layer
 *
 * Replaces the ES-module import of inline mock data with live BFF calls.
 * The HTML page includes this script BEFORE customer-360.js so the BFF-aware
 * functions are available when the page module initialises.
 *
 * This file is NOT a module (loaded as plain <script>) so it can patch
 * window-level globals that the module also reads.
 *
 * Mount order in customer-360.html:
 *   1. api.js              ← PHSAPI client
 *   2. customer-360-bff.js ← this file, patches module behaviour
 *   3. (module) customer-360.js  ← existing page module, unchanged
 */

(function () {
  'use strict';

  if (typeof PHSAPI === 'undefined') {
    console.warn('[C360-BFF] PHSAPI not found. BFF integration skipped.');
    return;
  }

  const LIFECYCLE_LABELS = {
    prospect: 'Prospect', lead: 'Lead', ekyc: 'eKYC',
    account_opening: 'Account Opening', funding: 'Funding',
    first_trade: 'First Trade', active_investor: 'Active Investor',
    vip: 'VIP', dormant: 'Dormant', churn_risk: 'Churn Risk',
    reactivation: 'Reactivation',
  };

  /**
   * Normalize a BFF customer response (either format) → flat UI format
   * that customer-360.js render functions expect.
   *
   * customers-v2 GET /api/customers/:id may return:
   *   { customer: { id, full_name, ... }, identities, recentEvents, ... }
   * OR (CDP profile store):
   *   flat { id, name, initials, metrics, journey, ... }
   */
  function normalizeBffCustomer(raw) {
    if (!raw) return null;

    // If response has nested `customer` key (customers-v2 format), flatten it
    const c = (raw.customer && typeof raw.customer === 'object') ? raw.customer : raw;

    // Build display name
    const name = c.name || c.full_name || c.email || `Customer ${c.id || c.c360_customer_id || '?'}`;

    // Build initials for avatar
    const initials = name
      .split(/\s+/)
      .slice(0, 2)
      .map(w => w[0] || '')
      .join('')
      .toUpperCase() || '?';

    // Custom attributes
    const attrs = c.custom_attributes || c.customAttributes || {};

    // Lifecycle
    const lifecycle = c.lifecycle_stage || c.lifecycle || 'unknown';
    const lifecycleLabel = LIFECYCLE_LABELS[lifecycle] || c.lifecycleLabel || lifecycle || 'Unknown';

    // Merge everything into flat shape
    const flat = {
      // identity
      id:               c.id || c.c360_customer_id,
      crmId:            c.crmId || c.c360_customer_id || c.id,
      name,
      initials,
      email:            c.email || '',
      phone:            c.phone || '',
      lifecycle,
      lifecycleLabel,
      status:           c.status || (c.last_seen_at || c.lastActive ? 'Active' : 'Inactive'),
      tier:             c.tier || attrs.customer_tier || 'bronze',
      segment:          c.segment || attrs.customer_segment || '',
      joinDate:         c.joinDate || (c.first_seen_at ? c.first_seen_at.split('T')[0] : ''),
      lastActive:       c.lastActive || c.last_seen_at || '',
      tradingFrequency: c.tradingFrequency || attrs.trading_frequency || 'unknown',
      cashUtilization:  c.cashUtilization !== undefined ? c.cashUtilization : (Number(attrs.cash_utilization) || 0),
      productInterests: Array.isArray(c.product_interests) ? c.product_interests
                        : Array.isArray(c.productInterests) ? c.productInterests : [],
      emailOpenRate:    c.emailOpenRate !== undefined ? c.emailOpenRate : (Number(attrs.email_open_rate) || 0),
      pushEngagement:   c.pushEngagement !== undefined ? c.pushEngagement : (Number(attrs.push_engagement) || 0),
      webVisits:        c.webVisits !== undefined ? c.webVisits : (Number(attrs.web_visits) || 0),
      productViews:     c.productViews !== undefined ? c.productViews : (Number(attrs.product_views) || 0),
      kycStatus:        c.kycStatus || c.kyc_status || '',

      // metrics — UI renderSummary() reads c.metrics.*
      metrics: c.metrics || {
        portfolioBand:   attrs.portfolio_band    || '—',
        tradingActivity: attrs.trading_activity  || 'Low',
        engagementScore: Number(attrs.engagement_score)  || 0,
        daysSinceLogin:  attrs.days_since_login !== undefined ? Number(attrs.days_since_login) : '—',
      },

      // journey — UI renderJourney() reads c.journey.*
      journey: c.journey || {
        currentStageIndex: 0,
        currentLabel:      lifecycleLabel,
        daysInStage:       '—',
        previousStage:     '—',
        nextLikelyStage:   '—',
      },

      // event/behavior defaults
      events:    c.events    || [],
      behavior:  c.behavior  || {},
      attributes: c.attributes || {},

      // enriched data from BFF response
      identities:     raw.identities     || c.identities     || [],
      consents:       raw.consents       || c.consents       || [],
      recentEvents:   raw.recentEvents   || c.recentEvents   || [],
      campaignHistory: raw.campaignHistory || c.campaignHistory || [],
      audiences:      raw.segments       || c.audiences      || [],

      source: raw.source || c.source || 'bff',
    };

    return flat;
  }

  // ── Customer list cache for the switcher dropdown ─────────────────────────
  let _customerListCache = null;

  async function fetchCustomerList(query) {
    try {
      const res = await PHSAPI.customers.list({ search: query, limit: 20 });
      _customerListCache = (res.data || res.customers || []).map(normalizeBffCustomer).filter(Boolean);
      return _customerListCache;
    } catch (err) {
      console.error('[C360-BFF] Failed to load customer list:', err.message);
      return _customerListCache || [];
    }
  }

  // ── Main customer fetch ───────────────────────────────────────────────────
  async function fetchCustomer(id) {
    try {
      const raw = await PHSAPI.customers.get(id);
      return normalizeBffCustomer(raw);
    } catch (err) {
      console.error(`[C360-BFF] Failed to load customer ${id}:`, err.message);
      return null;
    }
  }

  // ── Expose on window so the module can call them ──────────────────────────
  window.PHSC360 = {
    fetchCustomer,
    fetchCustomerList,
    getCache: () => _customerListCache,
  };

  // Pre-warm the customer list so the switcher feels instant
  fetchCustomerList('').then(list => {
    console.log(`[C360-BFF] Pre-warmed ${list.length} customers`);
  });

})();
