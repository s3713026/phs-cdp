/**
 * PHS CDP — Data Catalog Seed Data
 * Reset to empty — add events/attributes via the UI or API.
 */

const dataCatalog = {
  version: '2.0.0',
  lastUpdated: '2026-11-09T04:55:27Z',
  events: [],
  profileAttributes: [],
  sources: [],
};

module.exports = dataCatalog;
