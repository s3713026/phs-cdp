/**
 * CustomerService — Unified Customer Profile Store
 * Handles identity resolution + profile upserts + C360 retrieval
 */
const db = require('../db/pool');

const CustomerService = {

  /**
   * Find a customer by any identifier
   */
  async findByIdentifier(type, value) {
    const result = await db.query(`
      SELECT c.* FROM cdp_customers c
      JOIN cdp_identities i ON i.customer_id = c.id
      WHERE i.identifier_type = $1 AND i.identifier_value = $2
      LIMIT 1
    `, [type, value]);
    return result.rows[0] || null;
  },

  /**
   * Find by userId (c360_customer_id) or anonymous_id
   */
  async findByUserId(userId) {
    const result = await db.query(`
      SELECT * FROM cdp_customers
      WHERE c360_customer_id = $1
      LIMIT 1
    `, [userId]);
    if (result.rows[0]) return result.rows[0];
    // Try identity graph
    return this.findByIdentifier('c360_customer_id', userId);
  },

  async findByAnonymousId(anonymousId) {
    const result = await db.query(`
      SELECT * FROM cdp_customers WHERE anonymous_id = $1 LIMIT 1
    `, [anonymousId]);
    if (result.rows[0]) return result.rows[0];
    return this.findByIdentifier('anonymous_id', anonymousId);
  },

  /**
   * Upsert profile from RudderStack identify() event
   * @param {string} userId   - RudderStack userId (c360_customer_id)
   * @param {object} traits   - Profile traits from RS
   * @param {string} anonymousId
   */
  async upsertProfile(userId, traits = {}, anonymousId = null) {
    const client = await db.getClient();
    try {
      await client.query('BEGIN');

      // Build update fields
      const updates = {};
      if (traits.email)       updates.email = traits.email;
      if (traits.phone)       updates.phone = traits.phone;
      if (traits.name || traits.full_name)
                              updates.full_name = traits.name || traits.full_name;
      if (traits.lifecycle_stage) updates.lifecycle_stage = traits.lifecycle_stage;
      if (traits.kyc_status)  updates.kyc_status = traits.kyc_status;
      if (traits.product_interests)
                              updates.product_interests = JSON.stringify(traits.product_interests);

      if (anonymousId)        updates.anonymous_id = anonymousId;
      updates.last_seen_at  = new Date().toISOString();

      // Upsert into cdp_customers
      const setClauses = Object.entries(updates)
        .map(([k, _], i) => `${k} = $${i + 2}`)
        .join(', ');
      const values = [userId, ...Object.values(updates)];

      let customer;
      if (setClauses) {
        const result = await client.query(`
          INSERT INTO cdp_customers (c360_customer_id, ${Object.keys(updates).join(', ')}, first_seen_at)
          VALUES ($1, ${Object.keys(updates).map((_, i) => `$${i + 2}`).join(', ')}, NOW())
          ON CONFLICT (c360_customer_id) DO UPDATE SET ${setClauses}, updated_at = NOW()
          RETURNING *
        `, values);
        customer = result.rows[0];
      } else {
        // No traits — just ensure customer exists
        const result = await client.query(`
          INSERT INTO cdp_customers (c360_customer_id, first_seen_at)
          VALUES ($1, NOW())
          ON CONFLICT (c360_customer_id) DO UPDATE SET updated_at = NOW()
          RETURNING *
        `, [userId]);
        customer = result.rows[0];
      }

      // Upsert identities
      const identities = [
        { type: 'c360_customer_id', value: userId },
      ];
      if (traits.email) identities.push({ type: 'email', value: traits.email });
      if (traits.phone) identities.push({ type: 'phone', value: traits.phone });
      if (anonymousId)  identities.push({ type: 'anonymous_id', value: anonymousId });

      for (const id of identities) {
        if (!id.value) continue;
        await client.query(`
          INSERT INTO cdp_identities (customer_id, identifier_type, identifier_value, source)
          VALUES ($1, $2, $3, 'rudderstack')
          ON CONFLICT (identifier_type, identifier_value)
          DO UPDATE SET customer_id = $1
        `, [customer.id, id.type, id.value]);
      }

      await client.query('COMMIT');
      return customer;
    } catch (err) {
      await client.query('ROLLBACK');
      throw err;
    } finally {
      client.release();
    }
  },

  /**
   * Merge anonymous → known (from RS alias() event)
   * previousId = anonymous_id, userId = known c360_customer_id
   */
  async mergeIdentities(previousId, userId) {
    const client = await db.getClient();
    try {
      await client.query('BEGIN');

      // Find or create the known customer
      let knownCustomer = await this.findByUserId(userId);
      if (!knownCustomer) {
        const result = await client.query(`
          INSERT INTO cdp_customers (c360_customer_id, anonymous_id, first_seen_at)
          VALUES ($1, $2, NOW())
          ON CONFLICT (c360_customer_id) DO UPDATE SET anonymous_id = $2, updated_at = NOW()
          RETURNING *
        `, [userId, previousId]);
        knownCustomer = result.rows[0];
      }

      // Reassign all events from anonymous_id to known customer
      await client.query(`
        UPDATE c360_event
        SET cdp_customer_uuid = $1,
            customer_id = $2
        WHERE anonymous_id = $3 AND cdp_customer_uuid IS NULL
      `, [knownCustomer.id, knownCustomer.c360_customer_id || null, previousId]);

      // Link anonymous_id in identity graph
      await client.query(`
        INSERT INTO cdp_identities (customer_id, identifier_type, identifier_value, source)
        VALUES ($1, 'anonymous_id', $2, 'rudderstack')
        ON CONFLICT (identifier_type, identifier_value)
        DO UPDATE SET customer_id = $1
      `, [knownCustomer.id, previousId]);

      await client.query('COMMIT');
      return knownCustomer;
    } catch (err) {
      await client.query('ROLLBACK');
      throw err;
    } finally {
      client.release();
    }
  },

  /**
   * Get unified Customer 360 profile
   * Combines: cdp_customers + identities + events + consents
   */
  async getProfile(customerId) {
    const [customerRes, identitiesRes, eventsRes, consentsRes] = await Promise.all([
      db.query('SELECT * FROM cdp_customers WHERE id = $1', [customerId]),
      db.query('SELECT * FROM cdp_identities WHERE customer_id = $1 ORDER BY created_at ASC', [customerId]),
      db.query(`
        SELECT event_id AS id, event_name, event_category, channel AS source,
               occurred_at, properties, confidence_score, anonymous_id
        FROM c360_event
        WHERE cdp_customer_uuid = $1
        ORDER BY occurred_at DESC
        LIMIT 20
      `, [customerId]),
      db.query('SELECT * FROM cdp_consents WHERE customer_id = $1', [customerId]),
    ]);

    if (!customerRes.rows[0]) return null;

    return {
      customer:     customerRes.rows[0],
      identities:   identitiesRes.rows,
      recentEvents: eventsRes.rows,
      consents:     consentsRes.rows,
    };
  },

  /**
   * Insert a behavioral event
   */
  // NOTE: Primary event write path is IdentityResolutionService.recordEvent() → c360_event.
  // This method is a legacy helper kept for internal service use; it also writes to c360_event.
  async recordEvent(customerId, anonymousId, eventName, properties = {}, source = 'web', sessionId = null, rsMessageId = null) {
    const { v4: uuidv4 } = require('uuid');
    const result = await db.query(`
      INSERT INTO c360_event
        (event_id, cdp_customer_uuid, anonymous_id, event_name, event_category,
         channel, properties, session_id, rudderstack_message_id,
         occurred_at, received_at)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, NOW(), NOW())
      ON CONFLICT (rudderstack_message_id) DO NOTHING
      RETURNING event_id AS id
    `, [
      uuidv4(),
      customerId   || null,
      anonymousId  || null,
      eventName,
      properties.category || null,
      source,
      JSON.stringify(properties),
      sessionId    || null,
      rsMessageId  || null,
    ]);
    return result.rows[0];
  },

  /**
   * List customers (paginated)
   */
  async listCustomers({ limit = 50, offset = 0, lifecycle_stage, search } = {}) {
    let where = [];
    let params = [];
    let idx = 1;

    if (lifecycle_stage) {
      where.push(`c.lifecycle_stage = $${idx++}`);
      params.push(lifecycle_stage);
    }
    if (search) {
      // Also search in cdp_identities table (anonymousId, phone, email stored there)
      where.push(`(
        c.full_name ILIKE $${idx}
        OR c.email ILIKE $${idx}
        OR c.c360_customer_id ILIKE $${idx}
        OR c.anonymous_id ILIKE $${idx}
        OR EXISTS (
          SELECT 1 FROM cdp_identities i
          WHERE i.customer_id = c.id
            AND i.identifier_value ILIKE $${idx}
        )
      )`);
      params.push(`%${search}%`);
      idx++;
    }

    const whereClause = where.length ? `WHERE ${where.join(' AND ')}` : '';
    const result = await db.query(`
      SELECT c.* FROM cdp_customers c
      ${whereClause}
      ORDER BY c.last_seen_at DESC NULLS LAST
      LIMIT $${idx} OFFSET $${idx + 1}
    `, [...params, limit, offset]);

    const countResult = await db.query(`
      SELECT COUNT(*) FROM cdp_customers c ${whereClause}
    `, params);

    return {
      customers: result.rows,
      total: parseInt(countResult.rows[0].count),
    };
  },
};

module.exports = CustomerService;