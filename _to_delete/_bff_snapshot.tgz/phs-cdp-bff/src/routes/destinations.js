const express = require('express');
const router  = express.Router();
const fs      = require('fs');
const path    = require('path');
const { requireRole } = require('../middleware/rbac');

const DEST_TYPE_LABEL = {
  POSTGRES:    'PostgreSQL (Data Warehouse)',
  MAUTIC:      'Mautic (Marketing Automation)',
  BIGQUERY:    'BigQuery',
  REDSHIFT:    'Redshift',
  SNOWFLAKE:   'Snowflake',
  AMPLITUDE:   'Amplitude',
  MIXPANEL:    'Mixpanel',
  WEBHOOK:     'Webhook',
};

function loadDestinations() {
  const candidates = [
    process.env.WORKSPACE_CONFIG_PATH,
    path.join(__dirname, '../../workspaceConfig.json'),
    path.join(__dirname, '../../../phs-cdp-ui/rudderstack-setup/workspaceConfig.json'),
  ].filter(Boolean);

  for (const p of candidates) {
    if (fs.existsSync(p)) {
      try {
        const raw = JSON.parse(fs.readFileSync(p, 'utf8'));

        // Collect top-level destinations array (may be empty or absent)
        const topDests = raw.destinations || [];

        // Also extract embedded destinations from sources (normalized format
        // stores them as objects inside each source's Destinations array)
        const embeddedDestsMap = new Map();
        for (const src of (raw.sources || [])) {
          for (const d of (src.Destinations || src.destinations || [])) {
            if (!d || typeof d !== 'object') continue;
            const destId = d.ID || d.id;
            if (destId && !embeddedDestsMap.has(destId)) {
              embeddedDestsMap.set(destId, {
                id:          destId,
                name:        d.Name || d.name || '',
                destinationDefinitionId: (d.DestinationDefinition || {}).Name || d.destinationDefinitionId || d.type || 'WEBHOOK',
                enabled:     d.Enabled !== false && d.enabled !== false,
                config:      d.Config || d.config || {},
              });
            }
          }
        }

        // Merge: top-level takes precedence, then embedded
        const allDests = [...topDests];
        for (const [id, d] of embeddedDestsMap) {
          if (!allDests.find(x => (x.id || x.ID) === id)) allDests.push(d);
        }

        if (!allDests.length) continue; // try next candidate

        const sourceDestIds = new Set(
          (raw.sources || []).flatMap(s =>
            (s.Destinations || s.destinations || []).map(d =>
              typeof d === 'string' ? d : (d?.ID || d?.id)
            ).filter(Boolean)
          )
        );

        return allDests.map(d => ({
          id:          d.id || d.ID,
          name:        d.name || d.Name || '',
          type:        DEST_TYPE_LABEL[d.destinationDefinitionId] || d.destinationDefinitionId,
          typeId:      d.destinationDefinitionId,
          status:      (d.enabled !== false && d.Enabled !== false) ? 'connected' : 'disconnected',
          enabled:     d.enabled !== false && d.Enabled !== false,
          usedBySources: sourceDestIds.has(d.id || d.ID),
          config: d.config || d.Config || {},
          connection: d.config || d.Config || {},
          // Persisted UI-layer config (written back by the custom UI)
          advancedConfig:  d.advancedConfig  || {},
          deliveryConfig:  d.deliveryConfig  || { mode: 'Stream', retries: 3, timeout: 30 },
          consentConfig:   d.consentConfig   || { required: false, purposes: [] },
          dataSelection:   d.dataSelection   || {},
        }));
      } catch {
        // try next
      }
    }
  }
  return [];
}

router.get('/', requireRole('viewer'), (_req, res) => {
  const data = loadDestinations();
  res.json({ data, total: data.length, source: data.length ? 'workspaceConfig' : 'empty' });
});

router.get('/:id', requireRole('viewer'), (req, res) => {
  const data = loadDestinations();
  const d = data.find(x => x.id === req.params.id);
  if (!d) return res.status(404).json({ error: { message: 'Destination not found', code: 'NOT_FOUND' } });
  res.json(d);
});


// ─── RudderStack reload helper ────────────────────────────────────────────────
const http = require('http');
function reloadRudderStack() {
  const RS_HOST = process.env.RS_HOST || 'rudder-server';
  const RS_PORT = parseInt(process.env.RS_CONTROL_PORT || '8080');
  const RS_PASS = process.env.RUDDER_ADMIN_PASSWORD || 'PHS@Rudder2024!';
  const auth    = Buffer.from(`admin:${RS_PASS}`).toString('base64');
  // RS self-hosted config-from-file: try known admin reload endpoints
  const endpoints = ['/backend/config/refreshConfig', '/adminHandler'];
  function tryNext(i) {
    if (i >= endpoints.length) return;
    const opts = {
      hostname: RS_HOST, port: RS_PORT, path: endpoints[i], method: 'POST',
      headers: { Authorization: `Basic ${auth}`, 'Content-Type': 'application/json' },
    };
    const req = http.request(opts, r => {
      if (r.statusCode < 300) console.log(`[RS] reload OK via ${endpoints[i]} (${r.statusCode})`);
      else tryNext(i + 1);
    });
    req.on('error', () => tryNext(i + 1));
    req.end(JSON.stringify({ arg: 'reload-features' }));
  }
  tryNext(0);
}

// ─── WRITE operations ─────────────────────────────────────────────────────────
const WS_CANDIDATES = [
  path.join(__dirname, '../../workspaceConfig.json'),
  path.join(__dirname, '../../../phs-cdp-ui/rudderstack-setup/workspaceConfig.json'),
];
function getConfigPath() {
  for (const p of WS_CANDIDATES) if (fs.existsSync(p)) return p;
  return WS_CANDIDATES[0];
}

/**
 * Read config and return a normalized flat view:
 * { raw, sources, destinations }
 * `destinations` is a flat array of destination objects (from either top-level
 * or embedded inside source.Destinations[]).
 * `raw` is the original parsed JSON for reference.
 */
function readCfgFlat() {
  let raw = { sources: [], destinations: [] };
  try { raw = JSON.parse(fs.readFileSync(getConfigPath(), 'utf8')); } catch {}

  // Collect top-level destinations
  const topDests = (raw.destinations || []).map(d => ({ ...d }));

  // Collect embedded destinations from sources
  const embeddedMap = new Map();
  for (const src of (raw.sources || [])) {
    for (const d of (src.Destinations || src.destinations || [])) {
      if (!d || typeof d !== 'object') continue;
      const did = d.ID || d.id;
      if (did && !embeddedMap.has(did)) {
        embeddedMap.set(did, {
          id: did, name: d.Name || d.name || '',
          destinationDefinitionId: (d.DestinationDefinition || {}).Name || d.destinationDefinitionId || 'WEBHOOK',
          enabled: d.Enabled !== false && d.enabled !== false,
          config: d.Config || d.config || {},
          advancedConfig:  d.advancedConfig  || {},
          deliveryConfig:  d.deliveryConfig  || { mode: 'Stream', retries: 3, timeout: 30 },
          consentConfig:   d.consentConfig   || { required: false, purposes: [] },
          dataSelection:   d.dataSelection   || {},
          _embedded: true, // marker: lives inside source.Destinations
        });
      }
    }
  }

  // Merge: top-level takes precedence
  const destinations = [...topDests];
  for (const [id, d] of embeddedMap) {
    if (!destinations.find(x => (x.id || x.ID) === id)) destinations.push(d);
  }

  return { raw, destinations };
}

/**
 * Write a destination update back to the config file.
 * Handles both embedded (source.Destinations[]) and top-level destinations.
 */
function writeCfgDest(destId, updater) {
  const p = getConfigPath();
  let raw = { sources: [], destinations: [] };
  try { raw = JSON.parse(fs.readFileSync(p, 'utf8')); } catch {}

  // Try top-level first
  const topIdx = (raw.destinations || []).findIndex(d => (d.id || d.ID) === destId);
  if (topIdx !== -1) {
    raw.destinations[topIdx] = updater(raw.destinations[topIdx]);
    fs.writeFileSync(p, JSON.stringify(raw, null, 2));
    WS_CANDIDATES.filter(c => c !== p).forEach(c => { try { fs.writeFileSync(c, JSON.stringify(raw, null, 2)); } catch {} });
    return raw.destinations[topIdx];
  }

  // Try embedded in sources
  for (const src of (raw.sources || [])) {
    const arr = src.Destinations || src.destinations;
    if (!Array.isArray(arr)) continue;
    const idx = arr.findIndex(d => (d.ID || d.id) === destId);
    if (idx !== -1) {
      const updated = updater(arr[idx]);
      arr[idx] = updated;
      fs.writeFileSync(p, JSON.stringify(raw, null, 2));
      WS_CANDIDATES.filter(c => c !== p).forEach(c => { try { fs.writeFileSync(c, JSON.stringify(raw, null, 2)); } catch {} });
      return updated;
    }
  }

  return null; // not found
}

function uid(pfx) { return `${pfx}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,6)}`; }
function toUI(d) {
  const data = loadDestinations();
  return data.find(x => x.id === (d.id || d.ID)) || d;
}

// POST /destinations — create
router.post('/', requireRole('operator'), (req, res) => {
  try {
    const { name, destinationDefinitionId, config = {}, enabled = true, sourceIds = [] } = req.body;
    if (!name || !destinationDefinitionId) return res.status(400).json({ error: { message: 'name and destinationDefinitionId required' } });
    const p = getConfigPath();
    let raw = { sources: [], destinations: [] };
    try { raw = JSON.parse(fs.readFileSync(p, 'utf8')); } catch {}
    if (!Array.isArray(raw.destinations)) raw.destinations = [];
    const dest = { id: uid('dest'), name, destinationDefinitionId, enabled, config };
    raw.destinations.push(dest);

    // Link source → destination for each provided sourceId
    if (Array.isArray(sourceIds) && sourceIds.length > 0) {
      sourceIds.forEach(srcId => {
        const src = (raw.sources || []).find(s => (s.id || s.ID) === srcId);
        if (src) {
          if (!Array.isArray(src.destinations)) src.destinations = [];
          if (!src.destinations.find(d => d === dest.id || d?.id === dest.id)) {
            src.destinations.push({ id: dest.id, destinationId: dest.id });
          }
        }
      });
    }

    fs.writeFileSync(p, JSON.stringify(raw, null, 2));
    WS_CANDIDATES.filter(c => c !== p).forEach(c => { try { fs.writeFileSync(c, JSON.stringify(raw, null, 2)); } catch {} });
    reloadRudderStack();
    res.status(201).json(toUI(dest));
  } catch (e) { res.status(500).json({ error: { message: e.message } }); }
});

// PUT /destinations/:id — full update
router.put('/:id', requireRole('operator'), (req, res) => {
  try {
    const { raw, destinations } = readCfgFlat();
    const existing = destinations.find(d => d.id === req.params.id);
    if (!existing) return res.status(404).json({ error: { message: 'Destination not found' } });

    const { id, config, advancedConfig, deliveryConfig, consentConfig, dataSelection, ...rest } = req.body;
    const RS_ADV_KEYS = ['requestTimeout','maxAttempts','noOfWorkers','maxBatchSize',
      'uploadFreq','warehouseSyncFreq','enableDedup','skipTracksTable','skipUsersTable'];

    const updated = writeCfgDest(req.params.id, (d) => {
      const merged = {
        ...d, ...rest,
        ...(config !== undefined ? { config } : {}),
        ...(advancedConfig  !== undefined ? { advancedConfig }  : {}),
        ...(deliveryConfig  !== undefined ? { deliveryConfig }  : {}),
        ...(consentConfig   !== undefined ? { consentConfig }   : {}),
        ...(dataSelection   !== undefined ? { dataSelection }   : {}),
      };
      if (advancedConfig && typeof advancedConfig === 'object') {
        merged.config = merged.config || {};
        RS_ADV_KEYS.forEach(k => { if (advancedConfig[k] !== undefined) merged.config[k] = advancedConfig[k]; });
      }
      return merged;
    });

    if (!updated) return res.status(404).json({ error: { message: 'Destination not found' } });
    reloadRudderStack();
    res.json(toUI(updated));
  } catch (e) { res.status(500).json({ error: { message: e.message } }); }
});

// PATCH /destinations/:id — partial update (toggle enabled etc.)
router.patch('/:id', requireRole('operator'), (req, res) => {
  try {
    const { destinations } = readCfgFlat();
    const existing = destinations.find(d => d.id === req.params.id);
    if (!existing) return res.status(404).json({ error: { message: 'Destination not found' } });
    const updated = writeCfgDest(req.params.id, (d) => ({ ...d, ...req.body }));
    if (!updated) return res.status(404).json({ error: { message: 'Destination not found' } });
    res.json(toUI(updated));
  } catch (e) { res.status(500).json({ error: { message: e.message } }); }
});

// DELETE /destinations/:id — delete
router.delete('/:id', requireRole('operator'), (req, res) => {
  try {
    const p = getConfigPath();
    let raw = { sources: [], destinations: [] };
    try { raw = JSON.parse(fs.readFileSync(p, 'utf8')); } catch {}

    let found = false;
    // Remove from top-level
    const before = (raw.destinations || []).length;
    raw.destinations = (raw.destinations || []).filter(d => (d.id || d.ID) !== req.params.id);
    if (raw.destinations.length < before) found = true;
    // Remove from embedded source.Destinations[]
    for (const src of (raw.sources || [])) {
      for (const key of ['Destinations', 'destinations']) {
        if (Array.isArray(src[key])) {
          const b = src[key].length;
          src[key] = src[key].filter(d => typeof d === 'string' ? d !== req.params.id : (d.ID || d.id) !== req.params.id);
          if (src[key].length < b) found = true;
        }
      }
    }
    if (!found) return res.status(404).json({ error: { message: 'Destination not found' } });
    fs.writeFileSync(p, JSON.stringify(raw, null, 2));
    WS_CANDIDATES.filter(c => c !== p).forEach(c => { try { fs.writeFileSync(c, JSON.stringify(raw, null, 2)); } catch {} });
    reloadRudderStack();
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: { message: e.message } }); }
});

module.exports = router;
