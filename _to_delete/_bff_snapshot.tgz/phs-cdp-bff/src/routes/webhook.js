/**
 * Webhook Receiver — POST /api/webhook/rudderstack
 *
 * Receives events from RudderStack → routes through IdentityResolutionService
 * (tiered identity graph) → stores in cdp-postgres.
 *
 * Supported event types:
 *   identify → resolve/create profile + link identifiers
 *   alias    → merge anonymous → known (stitching)
 *   track    → behavioral event (resolve identity first)
 *   page     → page view (treated as track)
 *   screen   → mobile screen view (treated as track)
 *   group    → account/org grouping (future)
 */
const router = require('express').Router();
const IdentityResolutionService = require('../services/IdentityResolutionService');
const CustomerService           = require('../services/CustomerService');

// ─── Webhook secret verification ──────────────────────────────────────────────
function verifyWebhookSecret(req, res, next) {
  const secret = process.env.RUDDERSTACK_WEBHOOK_SECRET;
  if (!secret) return next(); // not configured — skip in dev

  const authHeader = req.headers['authorization'] || '';
  const token = authHeader.replace(/^Bearer\s+/i, '');
  if (token !== secret) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  next();
}

// ─── Main handler ─────────────────────────────────────────────────────────────
router.post('/rudderstack', verifyWebhookSecret, async (req, res) => {
  try {
    const payload = req.body;

    // RudderStack may send a single event or a batch array
    const events = Array.isArray(payload.batch) ? payload.batch : [payload];

    const results = [];
    for (const event of events) {
      try {
        const result = await processEvent(event);
        results.push({ type: event.type, status: 'ok', result });
      } catch (err) {
        console.error('[webhook] Event error:', err.message, '| type:', event.type,
          '| userId:', event.userId, '| anonymousId:', event.anonymousId);
        results.push({ type: event.type, status: 'error', error: err.message });
      }
    }

    res.json({ received: results.length, results });
  } catch (err) {
    console.error('[webhook] Fatal:', err.message);
    res.status(500).json({ error: 'Webhook processing failed' });
  }
});

// ─── Event router ─────────────────────────────────────────────────────────────
async function processEvent(event) {
  const type = (event.type || '').toLowerCase();

  switch (type) {

    // ── identify: resolve/create customer + link all traits as identifiers ────
    case 'identify': {
      const { userId, anonymousId, traits = {}, context = {}, messageId } = event;
      if (!userId && !anonymousId) return { skipped: 'no userId or anonymousId' };

      // Build identifiers object for tiered resolution
      const identifiers = buildIdentifiers({ userId, anonymousId, traits });

      const { customer, identifierType, confidenceScore, isNew } =
        await IdentityResolutionService.resolveIdentity(identifiers, {
          source: deriveSource(event),
          session_id: context.sessionId || null,
        });

      // Record the identify event itself
      await IdentityResolutionService.recordEvent(customer, confidenceScore, {
        event_name:              'Identify',
        event_category:          'identity',
        platform:                derivePlatform(event),
        channel:                 deriveSource(event),
        properties:              traits,
        occurred_at:             event.timestamp || event.originalTimestamp,
        received_at:             event.receivedAt,
        session_id:              context.sessionId,
        rudderstack_message_id:  messageId,
        anonymous_id:            anonymousId,
      });

      return { customerId: customer.id, identifierType, confidenceScore, isNew };
    }

    // ── alias: merge two identities (anonymous → known) ───────────────────────
    case 'alias': {
      const { userId, previousId } = event;
      if (!userId || !previousId) return { skipped: 'alias requires userId and previousId' };
      const customer = await CustomerService.mergeIdentities(previousId, userId);
      return { merged: true, customerId: customer?.id };
    }

    // ── track: behavioral event ───────────────────────────────────────────────
    case 'track': {
      return recordBehaviorEvent(event, event.event || 'Unknown Event', 'track');
    }

    // ── page: page view ───────────────────────────────────────────────────────
    case 'page': {
      const pageName = event.name || event.properties?.name || 'Unknown Page';
      return recordBehaviorEvent(event, `Page Viewed: ${pageName}`, 'page', {
        page_name:  event.name,
        page_url:   event.context?.page?.url,
        page_title: event.context?.page?.title,
        referrer:   event.context?.page?.referrer,
      });
    }

    // ── screen: mobile screen view ────────────────────────────────────────────
    case 'screen': {
      const screenName = event.name || 'Unknown Screen';
      return recordBehaviorEvent(event, `Screen Viewed: ${screenName}`, 'screen', {
        screen_name: event.name,
        ...event.properties,
      });
    }

    // ── group: account/org (future) ───────────────────────────────────────────
    case 'group': {
      return { skipped: 'group events not yet implemented' };
    }

    default:
      return { skipped: `unsupported type: ${type}` };
  }
}

// ─── Helper: behavioral event (track / page / screen) ────────────────────────
async function recordBehaviorEvent(event, eventName, category, extraProps = {}) {
  const { userId, anonymousId, properties = {}, context = {}, messageId } = event;

  // Always try to resolve identity first — even for anonymous events
  const identifiers = buildIdentifiers({ userId, anonymousId, traits: {} });
  let customer = null;
  let confidenceScore = 0;

  if (userId || anonymousId) {
    try {
      const resolved = await IdentityResolutionService.resolveIdentity(identifiers, {
        source: deriveSource(event),
        session_id: context.sessionId,
      });
      customer       = resolved.customer;
      confidenceScore = resolved.confidenceScore;
    } catch (err) {
      console.warn('[webhook] Identity resolution failed for event, storing anonymously:', err.message);
    }
  }

  const mergedProps = { ...properties, ...extraProps, category };

  if (customer) {
    // Write to c360_event (rich event table with confidence score)
    return IdentityResolutionService.recordEvent(customer, confidenceScore, {
      event_name:             eventName,
      event_category:         category,
      platform:               derivePlatform(event),
      channel:                deriveSource(event),
      properties:             mergedProps,
      occurred_at:            event.timestamp || event.originalTimestamp,
      received_at:            event.receivedAt,
      session_id:             context.sessionId,
      rudderstack_message_id: messageId,
      anonymous_id:           anonymousId,
    });
  }

  // Fully anonymous event — still record with no customer link
  return CustomerService.recordEvent(
    null, anonymousId || null,
    eventName, mergedProps,
    deriveSource(event),
    context.sessionId || null,
    messageId || null,
    null,
  );
}

// ─── Build identifiers object from event fields ───────────────────────────────
function buildIdentifiers({ userId, anonymousId, traits }) {
  return {
    phs_account_id:      userId            || null,
    email:               traits.email      || null,
    phone:               traits.phone      || null,
    national_id_raw:     traits.national_id || null,
    app_user_id:         traits.app_user_id || null,
    xpro_user_id:        traits.xpro_user_id || null,
    zalo_id:             traits.zalo_id    || null,
    cloudgo_contact_id:  traits.cloudgo_contact_id || null,
    anonymous_id:        anonymousId       || null,
    // Profile fields (not identifier keys)
    full_name:           traits.name || traits.full_name || null,
    c360_customer_id:    userId || null,
  };
}

// ─── Derive channel source from event context ─────────────────────────────────
function deriveSource(event) {
  const lib = (event.context?.library?.name || '').toLowerCase();
  if (lib.includes('android') || lib.includes('ios') || lib.includes('react-native')) return 'mobile';
  if (lib.includes('node') || lib.includes('python') || lib.includes('java'))         return 'server';
  return 'web';
}

function derivePlatform(event) {
  return event.context?.os?.name || event.context?.library?.name || 'web';
}

module.exports = router;
